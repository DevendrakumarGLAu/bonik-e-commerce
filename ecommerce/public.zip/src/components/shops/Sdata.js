const Sdata = {
  shopItems: [
    {
      id: 7,
      cover: "./images/shops/shop-1.jpg",
      name: "Azadi- Arundati Roy",
      price: "180",
      discount: "25",
    },
    {
      id: 8,
      cover: "./images/shops/2.jpg",
      name: "Vivo android one",
      price: "120",
      discount: "10",
    },
    {
      id: 9,
      cover: "./images/shops/3.jpg",
      name: "Sony Light",
      price: "20",
      discount: "50 ",
    },
    {
      id: 10,
      cover: "./images/shops/shops-3.jpg",
      name: "Iphone",
      price: "999",
      discount: "10 ",
    },
    {
      id: 11,
      cover: "./images/shops/shop-4.jpg",
      name: "Ceats wireless earphone",
      price: "80",
      discount: "20 ",
    },
    {
      id: 12,
      cover: "./images/shops/shops-2.jpg",
      name: "Redimi Phone",
      price: "400",
      discount: "20 ",
    },
    {
      id: 13,
      cover: "./images/shops/shops-6.jpg",
      name: "Xeats Bluetooth earphones",
      price: "60",
      discount: "5 ",
    },
    {
      id: 14,
      cover: "./images/shops/shops-7.jpg",
      name: "Airpod",
      price: "120",
      discount: "10",
    },
    {
      id: 15,
      cover: "./images/shops/shops-5.jpg",
      name: "Silver Cap",
      price: "5",
      discount: "2",
    },
  ],
}
export default Sdata

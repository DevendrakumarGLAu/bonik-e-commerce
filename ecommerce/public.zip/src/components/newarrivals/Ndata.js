const Ndata = [
  {
    cover: "./images/arrivals/image1.jpg",
    name: "Domestic Fiction",
    price: "150",
  },
  {
    cover: "./images/arrivals/image6.jpeg",
    name: "Mystery",
    price: "250",
  },
  {
    cover: "./images/arrivals/image5.jpg",
    name: "Thriller",
    price: "50",
  },
  {
    cover: "./images/arrivals/images.jpg",
    name: "Entertainment",
    price: "15",
  },
  {
    cover: "./images/arrivals/images3.jpg",
    name: "Novel",
    price: "10",
  },
  {
    cover: "./images/arrivals/The-Stolen-Heir.jpg",
    name: "Fantasy Fiction",
    price: "40",
  },
]

export default Ndata

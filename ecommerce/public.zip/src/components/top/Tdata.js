const Tdata = [
  {
    cover: "./images/top/top-1.jpeg",
    para: "Non-Fiction",
    desc: "3k orders this week",
  },
  {
    cover: "./images/top/top-2.jpg",
    para: "Fiction",
    desc: "4k orders this week",
  },
  {
    cover: "./images/top/top-3.jpg",
    para: "Entertainment",
    desc: "6k orders this week",
  },
  {
    cover: "./images/top/top-4.png",
    para: "History",
    desc: "4k orders this week",
  },
  {
    cover: "./images/top/top-5.jpg",
    para: "AutoBiography",
    desc: "6k orders this week",
  },
]

export default Tdata

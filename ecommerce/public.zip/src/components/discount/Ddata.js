const Ddata = [
  {
    cover: "./images/discount/letter.jpg",
    name: "A bunch of old letters",
    price: "$50",
  },
  {
    cover: "./images/discount/Death.jpg",
    name: "A Death in Shonagachhi",
    price: "$450",
  },
  {
    cover: "./images/discount/wealth.jpg",
    name: "The Wealth of Nations",
    price: "$50",
  },
  {
    cover: "./images/discount/Ajatshatru.jpg",
    name: "Ajatshatru-by Jay Shankar Prasad",
    price: "$100",
  },
  {
    cover: "./images/discount/darkness.jpg",
    name: "An Era of Darkness",
    price: "$20",
  },
  {
    cover: "./images/discount/world.jpg",
    name: "The World As I See It",
    price: "$200",
  },
  {
    cover: "./images/discount/simple.jpg",
    name: "A Simple Word",
    price: "$300",
  },
  {
    cover: "./images/discount/walking.jpg",
    name: "Walking with Giants",
    price: "$30",
  },
  {
    cover: "./images/discount/train.jpg",
    name: "The Night Train at Deoli",
    price: "$80",
  },
]
export default Ddata
